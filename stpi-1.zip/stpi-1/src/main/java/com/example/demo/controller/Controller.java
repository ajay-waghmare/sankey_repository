package com.example.demo.controller;

import com.example.demo.model.responsebody.ResponseBody;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import com.example.demo.exceptions.ResourceNotFoundException;
import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.services.EmployeeServices;

import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/employee")
@Slf4j
public class Controller {
	    @Autowired
	    EmployeeRepository employeeRepository;
	    
	    @Autowired
	    EmployeeServices employeeServices;
	    
	    private static final String HEADER_NAME = " Header Name: ";
	    private static final String HEADER_VALUE = " Header Value: ";
	
	    //get all employee
		@GetMapping("/get")
		public List<Employee> getAllEmployees() {
			return employeeRepository.findAll(); //findAll return list of Empyee objects
			}
		
		//get employee by id
		@GetMapping("/{id}")
		public Employee getUserById(@PathVariable (value = "id") long empId) {
			return this.employeeRepository.findById(empId)
					.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" +empId));
		}
		
		@GetMapping("/getEmpByStatus")
		public List<Employee> getByStatus(@RequestParam String status) {
			return employeeServices.getEmpByStatus(status); //findAll return list of Empyee objects
			}
		
//		
//		@GetMapping("/getEmpByStatus")
//		public ResponseEntity<String> getByStatusHeader(@RequestHeader(required=false) Map<String,String> headers) {
//			return employeeServices.getEmpByStatus(status); //findAll return list of Empyee objects
//			}
////		
//		
//		@GetMapping(path = "/myrequestheaders", produces = {MediaType.APPLICATION_JSON_VALUE} )
//	    public ResponseEntity<Map<String, String>> getMyRequestHeaders(
//	            @RequestHeader(value="Accept") String acceptHeader,
//	            @RequestHeader(value="Authorization") String authorizationHeader
//	            )
//	    {
//	        Map<String, String> returnValue = new HashMap<>();
//	        returnValue.put("Accept", acceptHeader);
//	        returnValue.put("Authorization", authorizationHeader);
//	        
//	        return ResponseEntity.status(HttpStatus.OK).body(returnValue);
//	    }
		
		@GetMapping("/header")
		public String listHeaders(@RequestHeader("status") String status) {
			return status;
		}
		
//		@GetMapping("/allheader")
//		public ResponseEntity<List<ResponseBody>> allHeaders (@RequestHeader(required=false) Map<String,String> headers) {
//			headers.forEach((key,value)->{
//				Log.info(HEADER_NAME + key + HEADER_VALUE + value);
//			});
//			
//			List<ResponseBody> Details = this.employeeServices.getEmpByStatus();
//            return new ResponseEntity<>(Details,HttpStatus.OK);
//	
//		}
//		
//		
		
		
		
		@PostMapping
		public Employee createUser(@RequestBody Employee employee) {
			return this.employeeRepository.save(employee);
		}
		
		@DeleteMapping("/{id}")
		public ResponseEntity<Employee> deleteUser(@PathVariable ("id") long empId) {
			Employee existingEmployee = this.employeeRepository.findById(empId)
			.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" +empId));
		  this.employeeRepository.delete(existingEmployee);
		  return ResponseEntity.ok().build();		
		}
	

}
