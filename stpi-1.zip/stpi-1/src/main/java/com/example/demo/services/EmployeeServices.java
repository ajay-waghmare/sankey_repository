package com.example.demo.services;

import com.example.demo.repository.EmployeeRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
@Service
public class EmployeeServices {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public List<Employee> getEmpByStatus(String status){
		return employeeRepository.findByStatus(status);
	}

}
