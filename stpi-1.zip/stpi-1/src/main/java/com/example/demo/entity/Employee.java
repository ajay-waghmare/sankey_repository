package com.example.demo.entity;

//import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="STPI")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	
	@Column()
	private String status;
	
	@Column()
	private String fname;
	
	@Column()
	private String lname;
	
	@Column()
	private String company_name;
	
	@Column()
	private String company_symbol;
	
	public Employee() {
		
	}
	public Employee(String status, String company_name, String company_symbol) {
		this.status=status; 
		this.company_name=company_name;
		this.company_symbol=company_symbol;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getCompanyName() {
		return company_name;
	}

	public void setCompanyName(String company_name) {
		this.company_name = company_name;
	}
	
	public String getCompanySymbol() {
		return company_symbol;
	}

	public void setCompanySymbol(String company_symbol) {
		this.company_symbol = company_symbol;
	}


}
